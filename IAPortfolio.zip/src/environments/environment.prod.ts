export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBVZ-gXQvRl7St1LF0muCWeXcH357YGAWc",
    authDomain: "iaportfolio.firebaseapp.com",
    projectId: "iaportfolio",
    storageBucket: "iaportfolio.appspot.com",
    messagingSenderId: "584980380763",
    appId: "1:584980380763:web:29f66bf04550c69f01137e"
  }
};
