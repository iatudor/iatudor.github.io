import { ScullyConfig } from '@scullyio/scully';
export const config: ScullyConfig = {
  projectRoot: "./src",
  projectName: "IAPortfolio",
  outDir: './dist/static',
  routes: {
  }
};